
The sonic screwdriver, also called a sonic probe or simply "the sonic", is a highly versatile tool used by many people throughout the universe, the most prominent of them being **the Doctor**.

![Screwdrivers](../images/all_e.png)  
